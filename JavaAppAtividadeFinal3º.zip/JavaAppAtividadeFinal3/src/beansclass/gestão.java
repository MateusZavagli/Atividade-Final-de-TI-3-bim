package beansclass;
/**
 * @author mateus.zlcarmo
 */
public class gest�o {
    private int id;
    private String cidade;
    private int comites;
    private int camaras;
    private int caixasdagua;
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getcidade(){
        return cidade;
    }
    
    public void setcidade(String cidade) {
        this.cidade = cidade;
    }
    
    public int getcomites(){
        return comites;
    }
    
    public void setcomites(int comites) {
        this.comites = comites;
    }
    
        public int getcamaras(){
        return camaras;
    }
    
    public void setcamaras(int camaras) {
        this.camaras = camaras;
    }
    
        public int getcaixasdagua(){
        return caixasdagua;
    }
    
    public void setcaixasdagua(int caixasdagua) {
        this.caixasdagua = caixasdagua;
    }
    
}
   
