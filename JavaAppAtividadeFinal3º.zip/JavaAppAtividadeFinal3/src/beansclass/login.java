package beansclass;
/**
 * @author mateus.zlcarmo
 */
public class login {
    private int id;
    private String senha;
    private String usuario;
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getsenha(){
        return senha;
    }
    
    public void setsenha(String senha) {
        this.senha = senha;
    }
    
    public String getusuario(){
        return usuario;
    }
    
    public void setusuario(String usuario) {
        this.usuario = usuario;
    }

}
