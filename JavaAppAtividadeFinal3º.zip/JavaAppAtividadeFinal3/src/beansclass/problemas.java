package beansclass;
/**
 * @author mateus.zlcarmo
 */
public class problemas {
    private int id;
    private String cidade;
    private String usuario;
    private String questao;
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getcidade(){
        return cidade;
    }
    
    public void setcidade(String cidade) {
        this.cidade = cidade;
    }
    
    public String getusuario(){
        return usuario;
    }
    
    public void setusuario(String usuario) {
        this.usuario = usuario;
    }
    
        public String getquestao(){
        return questao;
    }
    
    public void setquestao(String questao) {
        this.questao = questao;
    }
    
}
