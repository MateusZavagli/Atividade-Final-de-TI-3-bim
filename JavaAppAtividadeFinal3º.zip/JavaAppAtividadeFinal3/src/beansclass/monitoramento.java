package beansclass;
/**
 * @author mateus.zlcarmo
 */
public class monitoramento {
    private int id;
    private String cidade;
    private String qualidade;
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String cidade(){
        return cidade;
    }
    
    public void setcidade(String cidade) {
        this.cidade = cidade;
    }
    
    public String getqualidade(){
        return qualidade;
    }
    
    public void setqualidade(String qualidade) {
        this.qualidade = qualidade;
    }

    public String getcidade() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
   
