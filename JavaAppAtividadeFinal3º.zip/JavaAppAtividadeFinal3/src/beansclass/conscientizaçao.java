package beansclass;
/**
 * @author mateus.zlcarmo
 */
public class conscientiza�ao {
    private int id;
    private String cidade;
    private String cidadeconscientizada;
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getcidade(){
        return cidade;
    }
    
    public void setcidadeconscientizada(String cidadeconscientizada) {
        this.cidadeconscientizada = cidadeconscientizada;
    }

    public String getcidadeconscientizada() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setcidade(String string) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
