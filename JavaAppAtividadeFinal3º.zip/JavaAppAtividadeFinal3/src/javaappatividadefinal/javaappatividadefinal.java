package javaappatividadefinal;

import telas.menusemLogin;


public class javaappatividadefinal {
    public static void main(String[] args) {
      menusemLogin l = new menusemLogin();
      l.setVisible(true);
    }
}
    

